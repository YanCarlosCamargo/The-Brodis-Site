var precoFinal = 0;

var total = 0;
var soma = 0;

// *ATENÇÃO*     


//  Agora você poderá cadastrar os produtos de forma pratica e o sistema ira 
//      inserir tudo em seu devido lugar nos cards.

const items = [
    {
        id : 0, //o id identificará seu produto. nunca deixe um id igual ao outro.
        nome : 'Camiseta', //nome que parecerá no card.
        img : 'camisa.jpg', //aqui vai o nome do arquivo e sua extensão.
        desc: 'Camiseta vermelha do Internacional&reg;.', // aqui vai uma descrição do produto, 
                                                        // sempre tente deixar os tamanhos relativamente iguais.
        quantidade : 0, // Sempre deixe esta parte igual. Valor 0.
        preco: 20.99, // Coloque sempre as casas decimais.
        tema: "roupa", // Aqui os valores devem ser bebe, crianca, roupas, acessorio ou cosmeticos. cada um se encaixara na sua vitrine.
    }, // Copie qualquer um dos items e não se esqueça de fechá-los com as chaves e separá-los com *1" vírgula.
    {
        id : 1,
        nome : 'Shorts',
        img : 'shorts.jpg',
        desc: 'Shorts Florido com cardaço de Ajuste.',
        quantidade : 0,
        preco: 35.00,
        tema: "roupa"
    },
    {
        id : 2,
        nome : 'Sapato',
        img : 'sapato.jpg',
        desc: 'Sapato de couro na cor marrom.',
        quantidade : 0,
        preco: 78.90,
        tema: "roupa"
    },
    {
        id : 3,
        nome : 'Cinto',
        img : 'cinto.jpg',
        desc: 'Cinto na cor marrom com fivela de aço.',
        quantidade : 0,
        preco: 11.99,
        tema: "acessorio"
    },
    {
        id : 4,
        nome : 'Vans',
        img : 'tenis.jpg',
        desc: 'Tênis Vans&reg; na cor Preta e branca.',
        quantidade : 0,
        preco: 89.99,
        tema: "roupa"
    },
    {
        id : 5,
        nome : 'Bolsa',
        img : 'bolsa.jpg',
        desc: 'Bolsa Gouveia&reg; rosê e fivela dourada.',
        quantidade : 0,
        preco: 110.00,
        tema: "acessorio"
    },
    {
        id : 6,
        nome : 'Mochila',
        img : 'mochila.png',
        desc: 'Mochila preta com detalhes em vermelho.',
        quantidade : 0,
        preco: 49.90,
        tema: "acessorio"
    },
    {
        id : 7,
        nome : 'Calça',
        img : 'calca.jpg',
        desc: 'Calça Jogger preta com bolso.',
        quantidade : 0,
        preco: 150.00,
        tema: "roupa"
    },{
      id : 8,
      nome : 'Blusa Nike',
      img : 'blusa.jpg',
      desc: 'Blusa Nike&reg; na cor Branca com ziper.',
      quantidade : 0,
      preco: 190.00,
      tema: "roupa"
  },{
    id : 9,
    nome : 'Jaqueta Lacoste',
    img : 'jaqueta.jpg',
    desc: 'este jaqueta vai te deixar na moda',
    quantidade : 0,
    preco: 170.00,
    tema: "roupa"
},
{
  id : 10,
  nome : 'Relógio',
  img : 'relogio.jpg',
  desc: 'este relógio vai te deixar no Perigo, ele mostra a Hora como um relógio comum, tem ponteiros como um relógio comum, porém ele é comum.',
  quantidade : 0,
  preco: 329.99,
  tema: "acessorio"
},

,


]


inicializarLoja = () => { console.log('o valor de SOma é '+soma);
    console.log(' o valor de precoFinal é '+precoFinal);
    var containerProdutos = document.getElementById('tabela');
  






    var containerCarrinho = document.getElementById('produtos-carrinho');
    containerCarrinho.innerHTML = "<br><br><br><h3>Seu Carrinho está Vazio</h3>";
    items.map((val)=>{
            containerProdutos.innerHTML+= `       
              <div class="col">
                <div class="card  "  >
                  <img src="img/`+val.img+`" class="card-img-top" alt="...">
                  <div class="card-body" >
                    <h5 class="card-title">`+val.nome+`  </h5>
                    <p class="card-text">`+val.desc+`</p>
                      
                    </div>
                    <div class="card-footer">
             
                    <a  key="`+val.id+`" name="btn-adc" id="btn-preco" class="btn"   alt="Adicionar ao Carrinho"
                    
                                        
                    ><p id="btn-preco-txt">`+val.preco.toFixed(2)+` R$</p></a>
                    </div>
                </div>
              </div> 
                `;  
              })


             
             
             

             
              var iconeCarrinho = document.getElementById('icone-carrinho-nav');

              iconeCarrinho.innerHTML = `  
                          
              <a class="nav-link active" onclick="Mudarestado('pop') ">
              <svg xmlns="http://www.w3.org/2000/svg"   width="30" height="30" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
              </svg>
              </a>
               

            `

}




inicializarLoja();

atualizarCarrinho = () => {





  var botãoMovel = document.getElementById('botão-movel-carrinho');

  botãoMovel.innerHTML = `
  <a class="link" style="float: left; ">

  <span class="badge bg-secondary"  style="position:absolute; margin-left:25px; margih-bottom:10px; font-size: 0.8em"> `+soma+` </span>
  
    <svg xmlns="http://www.w3.org/2000/svg"   width="50" height="50" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
    </svg>
    </a>`;
  if (soma == 0){
    botãoMovel.style.animation = ('desaparecer 1500ms');
botãoMovel.style.display = ('none');

  } else {
    botãoMovel.style.animation = ('clarear 1500ms');
    botãoMovel.style.display = ('block');
  }





  var iconeCarrinho = document.getElementById('icone-carrinho-nav');

  iconeCarrinho.innerHTML = `                <span class="badge bg-warning text-dark" style="position: absolute">`+soma+`</span>
  <a class="nav-link active" onclick="Mudarestado('pop') ">
  <svg xmlns="http://www.w3.org/2000/svg"   width="30" height="30" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
  </svg>
  </a>
   
   
   `
   
   ;

   


    var containerCarrinho = document.getElementById('produtos-carrinho');
    containerCarrinho.innerHTML = "";
precoFinal.toFixed(2);

var containerResumo = document.getElementById('resumo');
containerResumo.innerHTML = `  <div id="total-de-produtos-p">Total de Produtos</div> <div id="total-de-produtos"><span class="badge bg-secondary"> `+soma+` </span></div>
                           
                       <div id="preco-final-carrinho">   <button onclick="finalizarCompra()" style="" id="badge-total-carrinho">  Total R$ `+precoFinal.toFixed(2)+`  </button> </div>
`;
    items.map((val)=>{
   
        if(val.quantidade > 0){

           
            
            containerCarrinho.innerHTML+= `

            <div id="listagem-de-produtos" >
                      <p id="nome-produto-carrinho">`+val.nome+`   `+val.preco.toFixed(2)+` R$ </>

                        <div id="sub-quant-adc">
                        <div  id="btn-sub">
                       <a href="#" key="`+val.id+`" name="btn-sub" onclick="subtrairProduto()"  class="btn btn-primary">
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                       <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                       <path fill-rule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                     </svg>
                     </a> 
                       </div>

                       <div id="quantidade-produto-carrinho"> 
                       <span class="badge bg-secondary">`+val.quantidade+` </span> 
                       </div>
                       
                       <div id="btn-adc2">
                       <a href="#" key="`+val.id+`" name="btn-adc2" onclick="adicionarProduto()"  class="btn btn-primary">
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square" viewBox="0 0 16 16">
                       <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                       <path fill-rule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                        </svg>
                       </a>
                     </div>
                     
                     </div>

                     </div>
                     <hr style="background-color:  #ffffff00;"> `
                     // ESTE HR SEM COR SEPARA OS PRODUTOS
                     
                       
                      

            
      
          
          

            

            ;

        }
            
    }) }

    

   



var links = document.getElementsByName('btn-adc');


for(var i = 0; i < links.length; i++){
links[i].addEventListener("click", function(){
    soma = 0;
    var key = this.getAttribute('key');
   
    items[key].quantidade++;


    
    soma =  +0;
    items.map((val)=>{
        if(val.quantidade > 0){ 
            
            soma = +val.quantidade + +soma }
            console.log('foi somado');
            
    })

    console.log(' o valor de precoFinal é '+precoFinal);

    items[key].preco.toFixed(2);
            
    precoFinal = precoFinal + items[key].preco;
    precoFinal.toFixed(2);
    console.log('O Valor de preço final é '+precoFinal);

    atualizarCarrinho();
    alert('Item adicionado com Sucesso!')
   
})

}
 ;
 var adc = document.getElementsByName('btn-adc2');

 
 adicionarProduto  = () => {

 for(var i = 0; i < adc.length; i++){
 adc[i].addEventListener("click", function(){
     soma = 0;
     var key = this.getAttribute('key');
    
     items[key].quantidade++;
       
     soma =  +0;
     items.map((val)=>{
         if(val.quantidade > 0){ 
             
             soma = +val.quantidade + +soma }
             console.log('foi somado');
     })
     items[key].preco.toFixed(2);
            
     precoFinal = precoFinal + items[key].preco;
     precoFinal.toFixed(2);
     console.log('O Valor de preço final é '+precoFinal);

     atualizarCarrinho();
    
 })}
  ;

 }

 var sub = document.getElementsByName('btn-sub');

 
subtrairProduto  = () => {

 for(var i = 0; i < sub.length; i++){
 sub[i].addEventListener("click", function(){
     soma = 0;
     var key = this.getAttribute('key');
    
     items[key].quantidade--;
       
     soma =  +0;
     items.map((val)=>{
         if(val.quantidade > 0){ 
             
             soma = +val.quantidade + +soma }
             console.log('foi subtraido');
     })

     items[key].preco.toFixed(2);
            
     precoFinal = precoFinal - items[key].preco;
     precoFinal.toFixed(2);
     console.log('O Valor de preço final é '+precoFinal);
     atualizarCarrinho();
    
 })}
  ;

 



 }


 teste = () => {
    precoFinal = 0 ;
     
         
        precoFinal = +precoFinal + +items.preco;
        precoFinal.toLocaleString('pt-BR');
        
      
    
    
    console.log(' o valor de precoFinal é '+precoFinal);
 }

 finalizarCompra = () => { if (soma > 0){
   var pedidoFinalizado = "*AJ - The Brodis* %20%0A%20%0A%20%0ACarrinho:  %20%0A%20%0A---------------------------------------%20%0A";
items.map((val) => {

  if(val.quantidade > 0){
  pedidoFinalizado = pedidoFinalizado+"%20%0A *"+ val.quantidade +"* X  *"+val.nome+"* " ; 
  }


})
pedidoFinalizado = pedidoFinalizado + "%20%0A%20%0A--------------------------------------- %20%0AProdutos no total: *"+soma+"*.  %20%0AO valor total dos produtos é *R$ "+precoFinal.toFixed(2)+"*." ;
//19783283163 tio andré
whats = "https://api.whatsapp.com/send?phone=5511974315565&text="+pedidoFinalizado;

console.log(pedidoFinalizado);
alert('Você será redirecionado para nosso Whatsapp para concluir seu pedido');
window.location.href = whats;
 } else {
   alert('Adicione Items ao carrinho para finalizar sua Compra!');
   fechar('pop');
   return false;
 }
 }


 